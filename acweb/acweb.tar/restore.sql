--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE acweb;
--
-- Name: acweb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE acweb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE acweb OWNER TO postgres;

\connect acweb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hr; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA hr;


ALTER SCHEMA hr OWNER TO postgres;

--
-- Name: sales; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA sales;


ALTER SCHEMA sales OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: staff; Type: TABLE; Schema: hr; Owner: postgres
--

CREATE TABLE hr.staff (
    staff_id integer NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    addr_id integer,
    email character varying(100),
    phone character varying(20),
    active boolean DEFAULT true NOT NULL,
    username character varying(50) NOT NULL
);


ALTER TABLE hr.staff OWNER TO postgres;

--
-- Name: staff_staff_id_seq; Type: SEQUENCE; Schema: hr; Owner: postgres
--

CREATE SEQUENCE hr.staff_staff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hr.staff_staff_id_seq OWNER TO postgres;

--
-- Name: staff_staff_id_seq; Type: SEQUENCE OWNED BY; Schema: hr; Owner: postgres
--

ALTER SEQUENCE hr.staff_staff_id_seq OWNED BY hr.staff.staff_id;


--
-- Name: address; Type: TABLE; Schema: sales; Owner: postgres
--

CREATE TABLE sales.address (
    addr_id integer NOT NULL,
    address character varying(100),
    address2 character varying(100),
    city_id integer NOT NULL,
    postal_code character varying(30)
);


ALTER TABLE sales.address OWNER TO postgres;

--
-- Name: address_addr_id_seq; Type: SEQUENCE; Schema: sales; Owner: postgres
--

CREATE SEQUENCE sales.address_addr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sales.address_addr_id_seq OWNER TO postgres;

--
-- Name: address_addr_id_seq; Type: SEQUENCE OWNED BY; Schema: sales; Owner: postgres
--

ALTER SEQUENCE sales.address_addr_id_seq OWNED BY sales.address.addr_id;


--
-- Name: category; Type: TABLE; Schema: sales; Owner: postgres
--

CREATE TABLE sales.category (
    cat_id integer NOT NULL,
    name character varying(50),
    description text
);


ALTER TABLE sales.category OWNER TO postgres;

--
-- Name: category_cat_id_seq; Type: SEQUENCE; Schema: sales; Owner: postgres
--

CREATE SEQUENCE sales.category_cat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sales.category_cat_id_seq OWNER TO postgres;

--
-- Name: category_cat_id_seq; Type: SEQUENCE OWNED BY; Schema: sales; Owner: postgres
--

ALTER SEQUENCE sales.category_cat_id_seq OWNED BY sales.category.cat_id;


--
-- Name: city; Type: TABLE; Schema: sales; Owner: postgres
--

CREATE TABLE sales.city (
    city_id integer NOT NULL,
    name character varying(50) NOT NULL,
    state_id integer NOT NULL
);


ALTER TABLE sales.city OWNER TO postgres;

--
-- Name: city_city_id_seq; Type: SEQUENCE; Schema: sales; Owner: postgres
--

CREATE SEQUENCE sales.city_city_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sales.city_city_id_seq OWNER TO postgres;

--
-- Name: city_city_id_seq; Type: SEQUENCE OWNED BY; Schema: sales; Owner: postgres
--

ALTER SEQUENCE sales.city_city_id_seq OWNED BY sales.city.city_id;


--
-- Name: customer; Type: TABLE; Schema: sales; Owner: postgres
--

CREATE TABLE sales.customer (
    customer_id integer NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    addr_id integer,
    email character varying(100),
    phone character varying(20)
);


ALTER TABLE sales.customer OWNER TO postgres;

--
-- Name: customer_customer_id_seq; Type: SEQUENCE; Schema: sales; Owner: postgres
--

CREATE SEQUENCE sales.customer_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sales.customer_customer_id_seq OWNER TO postgres;

--
-- Name: customer_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: sales; Owner: postgres
--

ALTER SEQUENCE sales.customer_customer_id_seq OWNED BY sales.customer.customer_id;


--
-- Name: payment; Type: TABLE; Schema: sales; Owner: postgres
--

CREATE TABLE sales.payment (
    payment_id integer NOT NULL,
    customer_id integer NOT NULL,
    amount numeric(6,2) NOT NULL,
    payment_date timestamp without time zone NOT NULL
);


ALTER TABLE sales.payment OWNER TO postgres;

--
-- Name: payment_payment_id_seq; Type: SEQUENCE; Schema: sales; Owner: postgres
--

CREATE SEQUENCE sales.payment_payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sales.payment_payment_id_seq OWNER TO postgres;

--
-- Name: payment_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: sales; Owner: postgres
--

ALTER SEQUENCE sales.payment_payment_id_seq OWNED BY sales.payment.payment_id;


--
-- Name: products; Type: TABLE; Schema: sales; Owner: postgres
--

CREATE TABLE sales.products (
    id integer NOT NULL,
    name character varying(50),
    cat_id integer NOT NULL,
    color character varying(50),
    description text,
    price numeric(6,2)
);


ALTER TABLE sales.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: sales; Owner: postgres
--

CREATE SEQUENCE sales.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sales.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: sales; Owner: postgres
--

ALTER SEQUENCE sales.products_id_seq OWNED BY sales.products.id;


--
-- Name: state; Type: TABLE; Schema: sales; Owner: postgres
--

CREATE TABLE sales.state (
    state_id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE sales.state OWNER TO postgres;

--
-- Name: state_state_id_seq; Type: SEQUENCE; Schema: sales; Owner: postgres
--

CREATE SEQUENCE sales.state_state_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sales.state_state_id_seq OWNER TO postgres;

--
-- Name: state_state_id_seq; Type: SEQUENCE OWNED BY; Schema: sales; Owner: postgres
--

ALTER SEQUENCE sales.state_state_id_seq OWNED BY sales.state.state_id;


--
-- Name: staff staff_id; Type: DEFAULT; Schema: hr; Owner: postgres
--

ALTER TABLE ONLY hr.staff ALTER COLUMN staff_id SET DEFAULT nextval('hr.staff_staff_id_seq'::regclass);


--
-- Name: address addr_id; Type: DEFAULT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.address ALTER COLUMN addr_id SET DEFAULT nextval('sales.address_addr_id_seq'::regclass);


--
-- Name: category cat_id; Type: DEFAULT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.category ALTER COLUMN cat_id SET DEFAULT nextval('sales.category_cat_id_seq'::regclass);


--
-- Name: city city_id; Type: DEFAULT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.city ALTER COLUMN city_id SET DEFAULT nextval('sales.city_city_id_seq'::regclass);


--
-- Name: customer customer_id; Type: DEFAULT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.customer ALTER COLUMN customer_id SET DEFAULT nextval('sales.customer_customer_id_seq'::regclass);


--
-- Name: payment payment_id; Type: DEFAULT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.payment ALTER COLUMN payment_id SET DEFAULT nextval('sales.payment_payment_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.products ALTER COLUMN id SET DEFAULT nextval('sales.products_id_seq'::regclass);


--
-- Name: state state_id; Type: DEFAULT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.state ALTER COLUMN state_id SET DEFAULT nextval('sales.state_state_id_seq'::regclass);


--
-- Data for Name: staff; Type: TABLE DATA; Schema: hr; Owner: postgres
--

COPY hr.staff (staff_id, first_name, last_name, addr_id, email, phone, active, username) FROM stdin;
\.
COPY hr.staff (staff_id, first_name, last_name, addr_id, email, phone, active, username) FROM '$$PATH$$/3779.dat';

--
-- Data for Name: address; Type: TABLE DATA; Schema: sales; Owner: postgres
--

COPY sales.address (addr_id, address, address2, city_id, postal_code) FROM stdin;
\.
COPY sales.address (addr_id, address, address2, city_id, postal_code) FROM '$$PATH$$/3769.dat';

--
-- Data for Name: category; Type: TABLE DATA; Schema: sales; Owner: postgres
--

COPY sales.category (cat_id, name, description) FROM stdin;
\.
COPY sales.category (cat_id, name, description) FROM '$$PATH$$/3773.dat';

--
-- Data for Name: city; Type: TABLE DATA; Schema: sales; Owner: postgres
--

COPY sales.city (city_id, name, state_id) FROM stdin;
\.
COPY sales.city (city_id, name, state_id) FROM '$$PATH$$/3767.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: sales; Owner: postgres
--

COPY sales.customer (customer_id, first_name, last_name, addr_id, email, phone) FROM stdin;
\.
COPY sales.customer (customer_id, first_name, last_name, addr_id, email, phone) FROM '$$PATH$$/3771.dat';

--
-- Data for Name: payment; Type: TABLE DATA; Schema: sales; Owner: postgres
--

COPY sales.payment (payment_id, customer_id, amount, payment_date) FROM stdin;
\.
COPY sales.payment (payment_id, customer_id, amount, payment_date) FROM '$$PATH$$/3777.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: sales; Owner: postgres
--

COPY sales.products (id, name, cat_id, color, description, price) FROM stdin;
\.
COPY sales.products (id, name, cat_id, color, description, price) FROM '$$PATH$$/3775.dat';

--
-- Data for Name: state; Type: TABLE DATA; Schema: sales; Owner: postgres
--

COPY sales.state (state_id, name) FROM stdin;
\.
COPY sales.state (state_id, name) FROM '$$PATH$$/3765.dat';

--
-- Name: staff_staff_id_seq; Type: SEQUENCE SET; Schema: hr; Owner: postgres
--

SELECT pg_catalog.setval('hr.staff_staff_id_seq', 820, true);


--
-- Name: address_addr_id_seq; Type: SEQUENCE SET; Schema: sales; Owner: postgres
--

SELECT pg_catalog.setval('sales.address_addr_id_seq', 1000, true);


--
-- Name: category_cat_id_seq; Type: SEQUENCE SET; Schema: sales; Owner: postgres
--

SELECT pg_catalog.setval('sales.category_cat_id_seq', 12, true);


--
-- Name: city_city_id_seq; Type: SEQUENCE SET; Schema: sales; Owner: postgres
--

SELECT pg_catalog.setval('sales.city_city_id_seq', 1000, true);


--
-- Name: customer_customer_id_seq; Type: SEQUENCE SET; Schema: sales; Owner: postgres
--

SELECT pg_catalog.setval('sales.customer_customer_id_seq', 1000, true);


--
-- Name: payment_payment_id_seq; Type: SEQUENCE SET; Schema: sales; Owner: postgres
--

SELECT pg_catalog.setval('sales.payment_payment_id_seq', 1000, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: sales; Owner: postgres
--

SELECT pg_catalog.setval('sales.products_id_seq', 36, true);


--
-- Name: state_state_id_seq; Type: SEQUENCE SET; Schema: sales; Owner: postgres
--

SELECT pg_catalog.setval('sales.state_state_id_seq', 1000, true);


--
-- Name: staff staff_email_key; Type: CONSTRAINT; Schema: hr; Owner: postgres
--

ALTER TABLE ONLY hr.staff
    ADD CONSTRAINT staff_email_key UNIQUE (email);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: hr; Owner: postgres
--

ALTER TABLE ONLY hr.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (staff_id);


--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (addr_id);


--
-- Name: category category_name_key; Type: CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.category
    ADD CONSTRAINT category_name_key UNIQUE (name);


--
-- Name: category category_pkey; Type: CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (cat_id);


--
-- Name: city city_pkey; Type: CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.city
    ADD CONSTRAINT city_pkey PRIMARY KEY (city_id);


--
-- Name: customer customer_email_key; Type: CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.customer
    ADD CONSTRAINT customer_email_key UNIQUE (email);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customer_id);


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (payment_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: state state_pkey; Type: CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.state
    ADD CONSTRAINT state_pkey PRIMARY KEY (state_id);


--
-- Name: staff addrfk; Type: FK CONSTRAINT; Schema: hr; Owner: postgres
--

ALTER TABLE ONLY hr.staff
    ADD CONSTRAINT addrfk FOREIGN KEY (addr_id) REFERENCES sales.address(addr_id);


--
-- Name: customer addrfk; Type: FK CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.customer
    ADD CONSTRAINT addrfk FOREIGN KEY (addr_id) REFERENCES sales.address(addr_id);


--
-- Name: products catfk; Type: FK CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.products
    ADD CONSTRAINT catfk FOREIGN KEY (cat_id) REFERENCES sales.category(cat_id);


--
-- Name: payment custfk; Type: FK CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.payment
    ADD CONSTRAINT custfk FOREIGN KEY (customer_id) REFERENCES sales.customer(customer_id);


--
-- Name: city stfk; Type: FK CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY sales.city
    ADD CONSTRAINT stfk FOREIGN KEY (state_id) REFERENCES sales.state(state_id);


--
-- PostgreSQL database dump complete
--

